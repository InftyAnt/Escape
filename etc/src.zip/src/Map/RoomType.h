#pragma once

// ���� ����
typedef enum {
	Empty,
	StartRoomType,
	BossRoomType,
	NormalRoomType,
	OneInOne,
	Tetris,
	Gaal,
	X,
	ZigZag,
	MAP_TYPE_COUNT
};