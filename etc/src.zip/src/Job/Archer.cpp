#include "Archer.h"
#include <iostream>

// ������
Archer::Archer(Direction dir) : Player(dir, ARCHER) {
    damage = 20;
    firstCool = DEFAULT_ARCHER_FIRST_COOL * FPS;
    secondCool = 0;
    firstCoolCount = firstCool;
    secondCoolCount = 0;
}

// ù ��° ��ų
void Archer::firstSkill() {
    if (firstCoolCount >= firstCool) {
        arrows.push_back(make_unique <Arrow> (direction, position, getEffectiveDamage()));
        firstCoolCount = 0;
    }
}

// �߻��ϰ� ȿ���� ����� ȭ�� ����
void Archer::deleteArrow() {
    for (auto it = arrows.begin(); it != arrows.end(); ) {
        if (!(*it)->isVisible) {
            it = arrows.erase(it);
        }
        else {
            ++it;
        }
    }
}