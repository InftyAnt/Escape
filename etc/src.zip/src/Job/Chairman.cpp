#include "Chairman.h"

// ������
Chairman::Chairman(Direction dir) : Player(dir, MEDIC) {
    firstCool = DEFAULT_CHAIRMAN_FIRST_COOL * FPS;
    secondCool = 0;
    firstCoolCount = firstCool;
    secondCoolCount = 0;

}

// ù ��° ��ų
void Chairman::firstSkill() {
    if (firstCoolCount >= firstCool) {
        chairs.push_back(make_unique <Chair>(direction, position, 25));
        firstCoolCount = 0;
    }
}

// �ֵθ��� ȿ���� ����� ���� ����
void Chairman::deleteChair() {
    for (auto it = chairs.begin(); it != chairs.end(); ) {
        if (!(*it)->isVisible) {
            it = chairs.erase(it);
        }
        else {
            ++it;
        }
    }
}
