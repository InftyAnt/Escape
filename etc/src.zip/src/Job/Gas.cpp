#include "Gas.h"
#include "../Main/GameManager.h"

// ������
Gas::Gas(Direction dir, pair <int, int> pos, int dmg) {
	isVisible = true;
	isAttacked = false;
	direction = dir;
	position = pos;
	damage = dmg;
	animationCount = GAS_ANIMATION_TIME * FPS;
}

// ���� �̵� (����)
void Gas::move(const GameManager& gameManager) {
    if (animationCount == 0) {
        isVisible = false;
        return;
    }
    animationCount--;

    if (isAttacked) {
        return;
    }

    // hitRange ��� �� �ش� ��ǥ ���� �ִ� ��� ������� Ÿ���� �� ������ Ÿ�� ���� ����
    hitRange = getAttackRange();
    for (const auto& pos : hitRange) {
        for (auto& z : gameManager.currRoom->zombies) {
            if (z->position == pos) {
                z->health -= damage;
                z->drawHealth();
                z->stun(GAS_STUN_FRAME);
                if (z->health <= 0) {
                    z->health = 0;
                    z->isAlive = false;
                }
            }
        }
    }
    isAttacked = true;
}

// ���� �׸���
void Gas::draw() {
    if (isVisible) {
        ofSetColor(ofColor::red, 127);
        for (const auto& pos : hitRange) {
            ofDrawRectangle(pos.first * CELL_SIZE, pos.second * CELL_SIZE, CELL_SIZE, CELL_SIZE);
        }
        ofSetColor(255, 255);
    }

}

// hitRange ���
vector<pair<int, int>> Gas::getAttackRange() {
    vector<pair<int, int>> range;
    int x = position.first;
    int y = position.second;

    // ���⿡ ���� hitRange ���
    switch (direction) {
    case Up:
        for (int i = -1; i <= 1; ++i) {
            for (int j = -3; j <= -1; ++j) {
                range.push_back(make_pair(x + i, y + j));
            }
        }
        break;
    case Down:
        for (int i = -1; i <= 1; ++i) {
            for (int j = 1; j <= 3; ++j) {
                range.push_back(make_pair(x + i, y + j));
            }
        }
        break;
    case Left:
        for (int i = -3; i <= -1; ++i) {
            for (int j = -1; j <= 1; ++j) {
                range.push_back(make_pair(x + i, y + j));
            }
        }
        break;
    case Right:
        for (int i = 1; i <= 3; ++i) {
            for (int j = -1; j <= 1; ++j) {
                range.push_back(make_pair(x + i, y + j));
            }
        }
        break;
    default:
        break;
    }

    return range;
}