#include "Medic.h"
#include <iostream>

// ������
Medic::Medic(Direction dir) : Player(dir, MEDIC) {
    firstCool = DEFAULT_MEDIC_FIRST_COOL * FPS;
    secondCool = 0;
    firstCoolCount = firstCool;
    secondCoolCount = 0;
}

// ù ��° ��ų
void Medic::firstSkill() {
    if (firstCoolCount >= firstCool) {
        syringes.push_back(make_unique <Syringe>(direction, position, 25));
        firstCoolCount = 0;
    }
}

// �߻��ϰ� ȿ���� ����� �ֻ�� ����
void Medic::deleteSyringe() {
    for (auto it = syringes.begin(); it != syringes.end(); ) {
        if (!(*it)->isVisible) {
            it = syringes.erase(it);
        }
        else {
            ++it;
        }
    }
}
