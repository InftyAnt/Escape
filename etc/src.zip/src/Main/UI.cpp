#include "UI.h"
#include "GameManager.h"
#include "../Object/Player.h"
#include "../Object/Zombie.h"
#include "../Map/Map.h"

// ������
UI::UI() {
	font1.load("verdana.ttf", 15);
}

// �Ҹ���
UI::~UI() {

}

// �̴ϸ� �׸���
void UI::drawMinimap(const GameManager& gameManager, const Map& map) {
	for (int i = 0; i < MAP_SIZE; i++) {
		for (int j = 0; j < MAP_SIZE; j++) {
			if (map.rooms[i][j]->isAvailable) {
				// ���� ���� ������, ��Ż ���� ���ֻ�, ���� ���� �ϴû�, �Ϲ� ���� ȸ������ ǥ��
				if (map.rooms[i][j]->isBoss) {
					ofSetColor(ofColor::red);
				}
				else if (map.rooms[i][j]->isPortal) {
					ofSetColor(255, 0, 255);
				}
				//else if (map.rooms[i][j]->isTreasure || map.rooms[i][j]->isShop) {
				//	ofSetColor(0, 255, 0);
				//}
				else if (map.rooms[i][j]->isStart) {
					ofSetColor(0, 255, 255);
				}
				else {
					ofSetColor(127);
				}
				ofDrawRectangle(MINIMAP_X + j * MINIMAP_CELL_SIZE, MINIMAP_Y + i * MINIMAP_CELL_SIZE, MINIMAP_SIZE, MINIMAP_SIZE);

				// ���� ���� ����� ���� ���簢���� �׸�
				if (map.rooms[i][j].get() == gameManager.currRoom) {
					ofSetColor(ofColor::black);
					ofDrawRectangle(MINIMAP_X + j * MINIMAP_CELL_SIZE + (MINIMAP_SIZE - CURR_ROOM_INDICATOR_SIZE) / 2, MINIMAP_Y + i * MINIMAP_CELL_SIZE + (MINIMAP_SIZE - CURR_ROOM_INDICATOR_SIZE) / 2, CURR_ROOM_INDICATOR_SIZE, CURR_ROOM_INDICATOR_SIZE);
				}
				
				// �ٸ� ��� ����Ǿ� ������ ���� ��� �׸�
				if (map.rooms[i][j]->neighbor[2]) {
					ofSetColor(127);
					ofDrawRectangle(MINIMAP_X + j * MINIMAP_CELL_SIZE + MINIMAP_SIZE / 2 - MINIMAP_GAP / 2, MINIMAP_Y + i * MINIMAP_CELL_SIZE + MINIMAP_SIZE, MINIMAP_GAP, MINIMAP_GAP);
				}
				if (map.rooms[i][j]->neighbor[3]) {
					ofSetColor(127);
					ofDrawRectangle(MINIMAP_X + j * MINIMAP_CELL_SIZE + MINIMAP_SIZE, MINIMAP_Y + i * MINIMAP_CELL_SIZE + MINIMAP_SIZE / 2 - MINIMAP_GAP / 2, MINIMAP_GAP, MINIMAP_GAP);
				}

				// Ŭ����� ���� �ʷϻ� �츦 �׸�
				if (map.rooms[i][j]->isClear && !map.rooms[i][j]->isStart && !map.rooms[i][j]->isPortal) {
					ofSetColor(0, 255, 0);
					ofDrawRectangle(MINIMAP_X + j * MINIMAP_CELL_SIZE, MINIMAP_Y + i * MINIMAP_CELL_SIZE, MINIMAP_SIZE, MINIMAP_W);
					ofDrawRectangle(MINIMAP_X + j * MINIMAP_CELL_SIZE, MINIMAP_Y + i * MINIMAP_CELL_SIZE, MINIMAP_W, MINIMAP_SIZE);
					ofDrawRectangle(MINIMAP_X + j * MINIMAP_CELL_SIZE, MINIMAP_Y + i * MINIMAP_CELL_SIZE + MINIMAP_SIZE - MINIMAP_W, MINIMAP_SIZE, MINIMAP_W);
					ofDrawRectangle(MINIMAP_X + j * MINIMAP_CELL_SIZE + MINIMAP_SIZE - MINIMAP_W, MINIMAP_Y + i * MINIMAP_CELL_SIZE, MINIMAP_W, MINIMAP_SIZE);
				}

				ofSetColor(255);
			}
		}
	}
}

// �÷��̾��� ü�¹� �׸���
void UI::drawHealthBar(const Player& player) {
	int barLength = HEALTHBAR_L * player.health / player.maxHealth;
	ofSetColor(127);
	ofDrawRectangle(HEALTHBAR_X, HEALTHBAR_Y - HEALTHBAR_STROKE_W, HEALTHBAR_L + 2 * HEALTHBAR_STROKE_W, HEALTHBAR_W + 2 * HEALTHBAR_STROKE_W);
	ofSetColor(ofColor::red);
	ofDrawRectangle(HEALTHBAR_X + HEALTHBAR_STROKE_W, HEALTHBAR_Y, barLength, HEALTHBAR_W);
	ofSetColor(255);

	// ü�� �ؽ�Ʈ ǥ��
	string healthText = to_string(player.health) + " / " + to_string(player.maxHealth);
	ofRectangle textBox = font1.getStringBoundingBox(healthText, 0, 0);
	float textX = HEALTHBAR_X + (HEALTHBAR_L + 2 * HEALTHBAR_STROKE_W - textBox.getWidth()) / 2;
	float textY = HEALTHBAR_Y + (HEALTHBAR_W + textBox.getHeight()) / 2 - textBox.getHeight() / 5;
	font1.drawString(healthText, textX, textY);
}

// ��ų�� ��Ÿ�� �׸���
void UI::drawCool(const Player& player) {
	// ������ �߽� ��ǥ�� ������ ����
	int centerX = ofGetWidth() - 5 * MINIMAP_CELL_SIZE / 2 - 20;
	int centerY = MINIMAP_CELL_SIZE * 5 + 120;
	int outerRadius = 80;
	int innerRadius = 65;
	float startAngle = -90;  // ���� ����(����)
	float endAngle = startAngle - 360 * player.firstCoolCount / player.firstCool;  // ���� ����(��Ÿ�� �ۼ�Ʈ�� ���� �޶���)

	// ��� ��� ���� �� �׸�
	ofSetColor(127);
	ofBeginShape();
	for (float angle = startAngle; angle >= startAngle - 360; angle -= 1) {
		float x = centerX + outerRadius * cos(ofDegToRad(angle));
		float y = centerY + outerRadius * sin(ofDegToRad(angle));
		ofVertex(x, y);
	}
	for (float angle = startAngle - 360; angle <= startAngle; angle += 1) {
		float x = centerX + innerRadius * cos(ofDegToRad(angle));
		float y = centerY + innerRadius * sin(ofDegToRad(angle));
		ofVertex(x, y);
	}
	ofEndShape(true);

	// ��Ÿ�� ������ ���� �� �׸�
	ofSetColor(ofColor::red);
	ofBeginShape();
	for (float angle = startAngle; angle >= endAngle; angle -= 1) {
		float x = centerX + outerRadius * cos(ofDegToRad(angle));
		float y = centerY + outerRadius * sin(ofDegToRad(angle));
		ofVertex(x, y);
	}
	for (float angle = endAngle; angle <= startAngle; angle += 1) {
		float x = centerX + innerRadius * cos(ofDegToRad(angle));
		float y = centerY + innerRadius * sin(ofDegToRad(angle));
		ofVertex(x, y);
	}
	ofEndShape(true);

	ofSetColor(255);
}

// �÷��̾��� �κ��丮 �׸���
void UI::drawInventory(const Player& player) {
	int x = 20;
	int y = 60;
	int w = 50;
	int sw = 5;

	ofSetColor(127);
	for (int i = 0; i < 5; i++) {
		for (int j = 0; j < 2; j++) {
			ofDrawRectangle(x + i * w, y + j * w, w + sw, sw);
			ofDrawRectangle(x + i * w, y + j * w, sw, w + sw);
			ofDrawRectangle(x + i * w, y + (j + 1) * w, w + sw, sw);
			ofDrawRectangle(x + (i + 1) * w, y + j * w, sw, w + sw);
		}
	}
	ofSetColor(255);
	int i = 0;
	for (const auto& item : player.inventory) {
		if (item) {
			// ���� ���� ���߱�
			int originalWidth = item->image.getWidth();
			int originalHeight = item->image.getHeight();
			float aspectRatio = static_cast<float>(originalWidth) / static_cast<float>(originalHeight);

			int drawWidth, drawHeight;
			if (originalWidth > originalHeight) {
				drawWidth = CELL_SIZE;
				drawHeight = static_cast<int>(CELL_SIZE / aspectRatio);
			}
			else {
				drawHeight = CELL_SIZE;
				drawWidth = static_cast<int>(CELL_SIZE * aspectRatio);
			}

			item->image.draw(x + CELL_SIZE * (i % 5) + CELL_SIZE / 2 - drawWidth / 2, y + CELL_SIZE * (i / 5) + CELL_SIZE / 2 - drawHeight / 2, drawWidth, drawHeight);
		}
		i++;
	}
}