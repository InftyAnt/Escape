#include "GameManager.h"

// ������
GameManager::GameManager(Job job) :
    player(make_unique<Player>(Down, ARCHER)),
    camera(GAMEBOARD_WIDTH* CELL_SIZE, GAMEBOARD_HEIGHT* CELL_SIZE, ROOM_SIZE* CELL_SIZE, ROOM_SIZE* CELL_SIZE),
    ui(),
    isGameOver(false) {

    map = make_unique<Map>(MIN_ROOM_CNT, MAX_ROOM_CNT);
    currRoom = map->start;

    fbo.allocate(CELL_SIZE * ROOM_SIZE, CELL_SIZE * ROOM_SIZE);
    fbo.begin();
    ofClear(255, 255, 255, 255);
    fbo.end();
    font.load("verdana.ttf", 32);
    initIP();

    // ���õ� �������� ����
    switch (job) {
    case ARCHER:
        changePlayer <Archer>();
        break;
    case MEDIC :
        changePlayer <Medic>();
        break;
    case CHAIRMAN:
        changePlayer <Chairman>();
        break;
    case FIREMAN:
        changePlayer <Fireman>();
        break;
    }

}

// �Ҹ���
GameManager::~GameManager() {
    fbo.destroy();
}

// ������Ʈ
void GameManager::update() {
    if (player->health == 0) isGameOver = true;
    if (isGameOver) return;

    // ���� �� �ൿ ������Ʈ
    Archer* archer = dynamic_cast<Archer*>(player.get());
    if (archer) {
        for (auto& arrow : archer->arrows) {
            arrow->move(*this);
        }
        archer->deleteArrow();
    }
    Medic* medic = dynamic_cast<Medic*>(player.get());
    if (medic) {
        for (auto& syringe : medic->syringes) {
            syringe->move(*this);
        }
        medic->deleteSyringe();
    }
    Chairman* chairman = dynamic_cast<Chairman*>(player.get());
    if (chairman) {
        for (auto& chair : chairman->chairs) {
            chair->move(*this);
        }
        chairman->deleteChair();
    }
    Fireman* fireman = dynamic_cast<Fireman*>(player.get());
    if (fireman) {
        for (auto& g : fireman->gas) {
            g->move(*this);
        }
        fireman->update(*currRoom);
    }
    else {
        player->update(*currRoom);
    }

    // ī�޶� ������Ʈ
    camera.update(*player);

    // ���� óġ �� ������ ���
    for (auto& z : currRoom->zombies) {
        z->update(player->position, currRoom->roomState, *player);
        if (!z->isAlive && !z->isItemDropped) {
            z->isItemDropped = true;
            if (ofRandom(100) <= ITEM_DROP_P) {
                auto item = getRandomItem();
                if (item) {
                    currRoom->droppedItems.push_back({ move(item), z->position });
                }
            }
        }
    }

    // �÷��̾��� ������ ȹ��
    if (player->isCPressed) {
        auto collectPosition = player->position;
        for (auto it = currRoom->droppedItems.begin(); it != currRoom->droppedItems.end();) {
            if (it->second == collectPosition) {
                auto itemPtr = it->first->clone();
                bool itemAdded = player->addItem(move(itemPtr));
                if (itemAdded) {
                    it = currRoom->droppedItems.erase(it);
                }
                else {
                    ++it;
                }
                player->isCPressed = false;
                break;
            }
            else {
                ++it;
            }
        }
    }

    // �÷��̾ ��Ż�� �������� �� �� ������ �̵�
    if (currRoom->isPortal && player->position == make_pair(currRoom->width / 2, currRoom->height / 2)) {
        createNewMap();
    }

    // �� ��ȯ
    changeRoom();
}

// �׸���
void GameManager::draw() {

    // ���� ȭ�� ���� ����
    fbo.begin();

    // ���� �� �׸���
    currRoom->draw(ui);

    if (!currRoom->isPortal && !currRoom->isStart && currRoom->allZombiesDefeated()) {
        currRoom->openDoors(*this);
    }

    // ���� �� ���� ���� �׸���
    Archer* archer = dynamic_cast<Archer*>(player.get());
    if (archer) {
        for (auto& arrow : archer->arrows) {
            arrow->draw();
        }
    }
    Medic* medic = dynamic_cast<Medic*>(player.get());
    if (medic) {
        for (auto& syringe : medic->syringes) {
            syringe->draw();
        }
    }
    Chairman* chairman = dynamic_cast<Chairman*>(player.get());
    if (chairman) {
        for (auto& chair : chairman->chairs) {
            chair->draw();
        }
    }
    Fireman* fireman = dynamic_cast<Fireman*>(player.get());
    if (fireman) {
        for (auto& g : fireman->gas) {
            if (fireman->drawCool > 0) {
                g->draw();
            }
        }
    }

    // �÷��̾� �׸���
    player->draw(ui);

    // ���� ȭ�� ���� ����
    fbo.end();

    // ui �׸���
    ui.drawMinimap(*this, *map);
    ui.drawHealthBar(*player);
    ui.drawCool(*player);
    ui.drawInventory(*player);

    // ���� ȭ�� ���
    int windowWidth = ofGetWidth();
    int windowHeight = ofGetHeight();
    int centerX = windowWidth / 2;
    int centerY = windowHeight / 2;

    fbo.getTexture().drawSubsection(
        (centerX - camera.width / 2),     // ȭ�� �߾ӿ� ���߱� ���� X ��ǥ
        (centerY - camera.height / 2),    // ȭ�� �߾ӿ� ���߱� ���� Y ��ǥ
        camera.width,                     // ȭ�鿡 �׸� �ʺ�
        camera.height,                    // ȭ�鿡 �׸� ����
        camera.x,                         // FBO���� �߶� ���� X ��ǥ
        camera.y,                         // FBO���� �߶� ���� Y ��ǥ
        camera.width,                     // �߶� �ʺ�
        camera.height                     // �߶� ����
    );

    // ���� ���� �� ���� ���� ���
    if (isGameOver) {
        drawGameOver();
    }
}

// �� ��ȯ
void GameManager::changeRoom() {
    for (int i = 0; i < DIRECTION_COUNT; i++) {
        if (player->direction == i && currRoom->neighbor[i] && player->position == currRoom->doors[i]) {
            int newRow = currRoom->row + dr[i], newCol = currRoom->col + dc[i];
            currRoom = map->rooms[newRow][newCol].get();
            player->telePort(ROOM_SIZE / 2 + ROOM_SIZE / 2 * dc[(i + 2) % 4], ROOM_SIZE / 2 + ROOM_SIZE / 2 * dr[(i + 2) % 4]);
            player->updateTargetPosition();
            camera.update(*player);
        }
    }
}

// ���� ���� �׸���
void GameManager::drawGameOver() {
    ofSetColor(127, 191);
    ofDrawRectangle(ofGetWidth() / 4, ofGetHeight() / 4, ofGetWidth() / 2, ofGetHeight() / 2);
    ofSetColor(255);
    string text = "G A M E     O V E R !";
    font.drawString(text, ofGetWidth() / 2 - font.stringWidth(text) / 2, ofGetHeight() / 2 - font.stringHeight(text) / 2);
}

// �÷��̾� ���� ����
template<typename T>
void GameManager::changePlayer() {
    auto oldPlayerState = player->position;
    auto oldPlayerHealth = player->health;

    player = make_unique<T>(player->direction);
    player->position = oldPlayerState;
    player->health = oldPlayerHealth;

    player->updateTargetPosition();
    camera.update(*player);
}

// ���� ������ ����
unique_ptr<Item> GameManager::getRandomItem() {
    int randVal = randInt(0, 99);
    int cumulativeProb = 0;
    for (const auto& itemPair : itemProbabilities) {
        cumulativeProb += itemPair.second;
        if (randVal <= cumulativeProb) {
            if (dynamic_cast<Bandage*>(itemPair.first.get())) {
                return make_unique<Bandage>();
            }
            else if (dynamic_cast<PainKiller*>(itemPair.first.get())) {
                return make_unique<PainKiller>();
            }
            else if (dynamic_cast<MedicalKit*>(itemPair.first.get())) {
                return make_unique<MedicalKit>();
            }
            else if (dynamic_cast<Multivitamin*>(itemPair.first.get())) {
                return make_unique<Multivitamin>();
            }
            else if (dynamic_cast<Protein*>(itemPair.first.get())) {
                return make_unique<Protein>();
            }
        }
    }
    return nullptr;
}

// �������� Ȯ�� ���� �ʱ�ȭ
void GameManager::initIP() {
    itemProbabilities.push_back({ make_unique<Bandage>(), 30 });
    itemProbabilities.push_back({ make_unique<PainKiller>(), 20 });
    itemProbabilities.push_back({ make_unique<MedicalKit>(), 10 });
    itemProbabilities.push_back({ make_unique<Multivitamin>(), 5 });
    itemProbabilities.push_back({ make_unique<Protein>(), 35 });
}

// �� �� ����
void GameManager::createNewMap() {
    auto newMap = make_unique<Map>(MIN_ROOM_CNT, MAX_ROOM_CNT);
    currRoom = newMap->start;

    player->health = player->maxHealth;
    player->position = { ROOM_SIZE / 2, ROOM_SIZE / 2 };
    player->updateTargetPosition();

    camera.update(*player);

    map = move(newMap);
}