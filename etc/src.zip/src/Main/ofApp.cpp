#include "ofApp.h"

// �ʱ� ����
void ofApp::setup(){

	ofSetFullscreen(false);
	ofSetFrameRate(FPS);
	ofBackground(0);
	isGameStarted = false;

}

// ������Ʈ
void ofApp::update(){
	if (isGameStarted) {
		gameManager->update();
	}
}

// �׸���
void ofApp::draw(){
	if (!isGameStarted) {
		jobSelectionManager.draw();
	}
	else {
		gameManager->draw();
	}
}

// ����
void ofApp::exit() {
	if (gameManager) {
		delete gameManager;
	}
}

// Ű �Է� ����
void ofApp::keyPressed(int key){
	if (!isGameStarted) {
		jobSelectionManager.keyPressed(key);
		if (jobSelectionManager.jobSelected) {
			gameManager = new GameManager(jobSelectionManager.selectedJob);
			isGameStarted = true;
		}
	}
	else {
		gameManager->player->keyPressed(key);
	}
}

// Ű �Է� ���� ����
void ofApp::keyReleased(int key) {
	if (isGameStarted) {
		gameManager->player->keyReleased(key);
	}
}