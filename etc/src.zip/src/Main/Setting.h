#pragma once

// ���ӿ� ���Ǵ� ��� ����

#define WINDOW_WIDTH 1920
#define WINDOW_HEIGHT 1080

#define FPS 120

#define CELL_SIZE 50

#define DEFAULT_PLAYER_SPEED 9
#define PLAYER_BLINK_FRAME FPS / 10

#define GAMEBOARD_WIDTH 25
#define GAMEBOARD_HEIGHT 15

#define GRID_LINE_WIDTH 5
#define DIRECTION_LINE_WIDTH 5

#define ROOM_SIZE 27
#define MAP_SIZE 5
#define MIN_ROOM_CNT 15
#define MAX_ROOM_CNT 22

#define MINIMAP_SIZE 21
#define MINIMAP_GAP 9
#define MINIMAP_CELL_SIZE 30
#define MINIMAP_X WINDOW_WIDTH - 170
#define MINIMAP_Y 20
#define MINIMAP_W 3

#define CURR_ROOM_INDICATOR_SIZE 12

#define HEALTHBAR_X 20
#define HEALTHBAR_Y 20
#define HEALTHBAR_L (250 - HEALTHBAR_STROKE_W)
#define HEALTHBAR_W 20
#define HEALTHBAR_STROKE_W 5

#define MIN_ZOMBIE_CNT 5
#define MAX_ZOMBIE_CNT 10
#define SLOW_ZOMBIE_SPEED 2
#define BOSS_ZOMBIE_MUL 3

#define ENTITY_HEALTH_DRAW_TIME 2 * FPS
#define ENTITY_HEALTHBAR_Y -14
#define ENTITY_HEALTHBAR_W 5
#define ENTITY_HEALTHBAR_STROKE_W 2

#define DEFAULT_ARCHER_FIRST_COOL 0.6
#define ARROW_SPEED 16

#define DEFAULT_MEDIC_FIRST_COOL 1
#define SYRINGE_SPEED 12
#define SYRINGE_STUN_FRAME FPS
#define SYRINGE_W 2

#define DEFAULT_CHAIRMAN_FIRST_COOL 0.5
#define CHAIR_ANIMATION_TIME 0.2

#define GAS_STORAGE 29160
#define GAS_CHARGE 27
#define GAS_DISCHARGE 16
#define GAS_SACRIFICE 3240
#define GAS_STUN_FRAME 0.5 * FPS
#define GAS_COOL 0.2
#define GAS_DAMAGE 6
#define GAS_ANIMATION_TIME GAS_COOL

#define FIRST_SKILL_SHOW_L 100
#define FIRST_SKILL_SHOW_W 10
#define FIRST_SKILL_SHOW_X WINDOW_WIDTH - FIRST_SKILL_SHOW_L - 20
#define FIRST_SKILL_SHOW_Y MINIMAP_CELL_SIZE * 5 + 40

#define INVENTORY_SIZE 10
#define ITEM_DROP_P 8

#include <iostream>
using namespace std;

// ���� ����
typedef enum {
	NONE,
	ARCHER,
	MEDIC,
	CHAIRMAN,
	FIREMAN
} Job;

// ����
typedef enum {
	Up,
	Left,
	Down,
	Right,
	DIRECTION_COUNT
} Direction;

// ����
extern int dr[DIRECTION_COUNT];
extern int dc[DIRECTION_COUNT];

// ������ �� ��ȯ
int randInt(int min, int max);
int randInt(int max);